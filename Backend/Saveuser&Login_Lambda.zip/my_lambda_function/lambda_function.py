import json
import requests
import boto3
from jose import jwt, jwk
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry
from jose.utils import base64url_decode
from datetime import datetime , timezone

# Initialize DynamoDB client
dynamodb = boto3.client('dynamodb')
table_name = 'Users'

# Cognito details
cognito_pool_region = 'ap-south-1'
cognito_pool_id = 'ap-south-1_yD5k4ylI6'
client_id = '76e6r6k2nssrnqe5k428qcgqod'
redirect_uri = 'https://d9rcwfrwbqgvj.cloudfront.net'

# Global variable to hold JWT keys
jwt_keys = None

def fetch_cognito_jwt_keys():
    jwks_url = f'https://cognito-idp.{cognito_pool_region}.amazonaws.com/{cognito_pool_id}/.well-known/jwks.json'
    response = requests.get(jwks_url)
    response.raise_for_status()
    return response.json()['keys']

def decode_jwt(token, jwt_keys):
    try:
        header = jwt.get_unverified_header(token)
        key = next((k for k in jwt_keys if k['kid'] == header['kid']), None)
        if not key:
            raise ValueError('Unable to find appropriate key for JWT verification')

        public_key = jwk.construct(key)
        message, encoded_signature = str(token).rsplit('.', 1)
        decoded_signature = base64url_decode(encoded_signature.encode('utf-8'))

        if not public_key.verify(message.encode("utf8"), decoded_signature):
            raise ValueError('Signature verification failed')

        payload = jwt.decode(
            token,
            public_key.to_dict(),
            algorithms=['RS256'],
            audience=client_id,
            issuer=f'https://cognito-idp.{cognito_pool_region}.amazonaws.com/{cognito_pool_id}',
            options={'verify_at_hash': False}  # Skip at_hash validation
        )
        return payload
    except Exception as e:
        raise ValueError(f'Error decoding JWT: {str(e)}')

def lambda_handler(event, context):
    global jwt_keys  # Use the global jwt_keys variable
    try:
        print("Received event: " + json.dumps(event, indent=2))
        
        http_method = event['httpMethod']
        print(f"HTTP Method: {http_method}")

        if http_method == 'OPTIONS':
            return {
                'statusCode': 200,
                'headers': {
                    'Access-Control-Allow-Origin': '*',
                    'Access-Control-Allow-Headers': 'Content-Type, Authorization',
                    'Access-Control-Allow-Methods': 'OPTIONS, GET, POST'
                },
                'body': json.dumps({'message': 'OPTIONS request handled'})
            }
        elif http_method == 'GET':
            return {
                'statusCode': 200,
                'headers': {
                    'Access-Control-Allow-Origin': '*',
                    'Access-Control-Allow-Headers': 'Content-Type, Authorization',
                    'Access-Control-Allow-Methods': 'OPTIONS, GET, POST'
                },
                'body': json.dumps({'message': 'Welcome to the API. Please use POST method to exchange code for tokens.'})
            }
        elif http_method == 'POST':
            body = json.loads(event['body'])
            code = body.get('code')
            print(f"Authorization code: {code}")

            if not code:
                return {
                    'statusCode': 400,
                    'headers': {
                        'Access-Control-Allow-Origin': '*',
                        'Access-Control-Allow-Headers': 'Content-Type, Authorization',
                        'Access-Control-Allow-Methods': 'OPTIONS, GET, POST'
                    },
                    'body': json.dumps({'message': 'Authorization code is required'})
                }

            token_endpoint = f'https://ap-south-1yd5k4yli6.auth.ap-south-1.amazoncognito.com/oauth2/token'
            params = {
                'grant_type': 'authorization_code',
                'client_id': client_id,
                'redirect_uri': redirect_uri,
                'code': code
            }

            print("Token request parameters: " + json.dumps(params, indent=2))

            session = requests.Session()
            retries = Retry(total=5, backoff_factor=0.2, status_forcelist=[500, 502, 503, 504])
            session.mount('https://', HTTPAdapter(max_retries=retries))

            response = session.post(token_endpoint, data=params, headers={'Content-Type': 'application/x-www-form-urlencoded'})

            print("Token endpoint response: " + response.text)
            print(f"Response status code: {response.status_code}")

            if response.status_code != 200:
                return {
                    'statusCode': response.status_code,
                    'headers': {
                        'Access-Control-Allow-Origin': '*',
                        'Access-Control-Allow-Headers': 'Content-Type, Authorization',
                        'Access-Control-Allow-Methods': 'OPTIONS, GET, POST'
                    },
                    'body': json.dumps({
                        'message': 'Failed to exchange authorization code for tokens',
                        'error': response.text
                    })
                }

            tokens = response.json()
            print("Tokens: " + json.dumps(tokens, indent=2))

            id_token = tokens.get('id_token')
            access_token = tokens.get('access_token')

            if not id_token or not access_token:
                return {
                    'statusCode': 400,
                    'headers': {
                        'Access-Control-Allow-Origin': '*',
                        'Access-Control-Allow-Headers': 'Content-Type, Authorization',
                        'Access-Control-Allow-Methods': 'OPTIONS, GET, POST'
                    },
                    'body': json.dumps({'message': 'Both ID token and access token are required'})
                }

            if jwt_keys is None:  # Fetch JWT keys only if not already fetched
                jwt_keys = fetch_cognito_jwt_keys()

            user_info = decode_jwt(id_token, jwt_keys)
            print("User info: " + json.dumps(user_info, indent=2))

            email = user_info.get('email')
            given_name = user_info.get('given_name')
            family_name = user_info.get('family_name')
            name = user_info.get('name')
            sub = user_info.get('sub')

            if not email or not sub:
                return {
                    'statusCode': 400,
                    'headers': {
                        'Access-Control-Allow-Origin': '*',
                        'Access-Control-Allow-Headers': 'Content-Type, Authorization',
                        'Access-Control-Allow-Methods': 'OPTIONS, GET, POST'
                    },
                    'body': json.dumps({'message': 'Email and sub are required'})
                }

            existing_user = dynamodb.get_item(
                TableName=table_name,
                Key={'email': {'S': email}}
            ).get('Item')

            print("Existing user: " + json.dumps(existing_user, indent=2))

            '''# If user exists, check subscription and phone status
            if existing_user:
                subscription = existing_user.get('subscription', {'S': 'none'})['S']
                phone = existing_user.get('phone', {'S': 'none'})['S']

                if subscription == 'Premium' and phone != 'none':
                    subscriber_response = dynamodb.get_item(
                        TableName=subscribers_table,
                        Key={'email': {'S': email}}
                    )
                    

                    if 'Item' in subscriber_response:
                        
                        end_date_str = subscriber_response['Item']['end_date']['S']
                        end_date = datetime.strptime(end_date_str, "%Y-%m-%d")
                        end_date = end_date.replace(tzinfo=timezone.utc)
                        
                        current_date = datetime.now(timezone.utc)
                        current_date = current_date.replace(tzinfo=timezone.utc)
                        

                        if end_date< current_date :
                             subscription = 'Expired'
                             dynamodb.update_item(
                                TableName=table_name,
                                Key={'email': {'S': email}},
                                UpdateExpression="set subscription = :s",
                                ExpressionAttributeValues={':s': {'S': subscription}}
                                )
    
                        # Add subscription and phone details to tokens
                        tokens.update({
                            'subscription': subscription,
                            'phone': phone
                        })

                # Add subscription and phone details to tokens
                else:
                    tokens.update({
                        'subscription': subscription,
                        'phone': phone
                    })
'''
            # If user does not exist, add to Users table
            if not existing_user:
                dynamodb.put_item(
                    TableName=table_name,
                    Item={
                        'email': {'S': email},
                        'sub': {'S': sub},
                        'given_name': {'S': given_name},
                        'family_name': {'S': family_name},
                        'name': {'S': name},
                    }
                )
            return {
                'statusCode': 200,
                'headers': {
                    'Access-Control-Allow-Origin': '*',
                    'Access-Control-Allow-Headers': 'Content-Type, Authorization',
                    'Access-Control-Allow-Methods': 'OPTIONS, GET, POST'
                },
                'body': json.dumps(tokens)
            }

        else:
            return {
                'statusCode': 405,
                'headers': {
                    'Access-Control-Allow-Origin': '*',
                    'Access-Control-Allow-Headers': 'Content-Type, Authorization',
                    'Access-Control-Allow-Methods': 'OPTIONS, GET, POST'
                },
                'body': json.dumps({'message': 'Method not allowed'})
            }

    except requests.exceptions.RequestException as e:
        print("RequestException: " + str(e))
        return {
            'statusCode': 500,
            'headers': {
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Headers': 'Content-Type, Authorization',
                'Access-Control-Allow-Methods': 'OPTIONS, GET, POST'
            },
            'body': json.dumps({'message': 'Network error: ' + str(e)})
        }
    except Exception as e:
        print("Exception: " + str(e))
        return {
            'statusCode': 500,
            'headers': {
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Headers': 'Content-Type, Authorization',
                'Access-Control-Allow-Methods': 'OPTIONS, GET, POST'
            },
            'body': json.dumps({'message': str(e)})
        }