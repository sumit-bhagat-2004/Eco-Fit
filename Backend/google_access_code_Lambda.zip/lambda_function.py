import json
import requests

COGNITO_DOMAIN = "ap-south-1yd5k4yli6.auth.ap-south-1.amazoncognito.com"

def get_google_access_token(cognito_access_token):
    """Retrieve Google Access Token from Cognito User Info endpoint."""
    url = f"https://{COGNITO_DOMAIN}/oauth2/userInfo"
    
    headers = {
        "Authorization": f"Bearer {cognito_access_token}"
    }
    
    try:
        response = requests.get(url, headers=headers)
        response.raise_for_status()
        user_info = response.json()
        return get_google_access_token(user_info)
        
        # Extract Google access token from identities array
        identities = user_info.get("identities", [])
        if identities and "access_token" in identities[0]:
            return {
                "statusCode": 200,
                "headers": {
                    "Access-Control-Allow-Origin": "*",  # Allow all origins (or set specific domain)
                    "Access-Control-Allow-Methods": "OPTIONS, GET, POST",
                    "Access-Control-Allow-Headers": "Content-Type, Authorization"
                },
                "body": json.dumps({
                    "google_access_token": identities[0]["access_token"]
                })
            }
        else:
            return {
                "statusCode": 400,
                "headers": {
                    "Access-Control-Allow-Origin": "*",
                    "Access-Control-Allow-Methods": "OPTIONS, GET, POST",
                    "Access-Control-Allow-Headers": "Content-Type, Authorization"
                },
                "body": json.dumps({"error": "No Google access token found."})
            }
    except requests.exceptions.RequestException as e:
        return {
            "statusCode": 500,
            "headers": {
                "Access-Control-Allow-Origin": "*",
                "Access-Control-Allow-Methods": "OPTIONS, GET, POST",
                "Access-Control-Allow-Headers": "Content-Type, Authorization"
            },
            "body": json.dumps({"error": str(e)})
        }

def lambda_handler(event, context):
    """AWS Lambda handler function with CORS support."""
    
    # Handle preflight (OPTIONS) request for CORS
    if event.get("httpMethod") == "OPTIONS":
        return {
            "statusCode": 200,
            "headers": {
                "Access-Control-Allow-Origin": "*",
                "Access-Control-Allow-Methods": "OPTIONS, GET, POST",
                "Access-Control-Allow-Headers": "Content-Type, Authorization"
            },
            "body": json.dumps({"message": "CORS preflight response"})
        }

    # Extract Cognito access token from headers or request body
    cognito_access_token = None
    
    if "headers" in event and "Authorization" in event["headers"]:
        cognito_access_token = event["headers"]["Authorization"].replace("Bearer ", "")
    
    if not cognito_access_token and "body" in event:
        body = json.loads(event["body"])
        cognito_access_token = body.get("cognito_access_token")
    
    if not cognito_access_token:
        return {
            "statusCode": 400,
            "headers": {
                "Access-Control-Allow-Origin": "*",
                "Access-Control-Allow-Methods": "OPTIONS, GET, POST",
                "Access-Control-Allow-Headers": "Content-Type, Authorization"
            },
            "body": json.dumps({"error": "Cognito access token is required"})
        }

    return get_google_access_token(cognito_access_token)
