import json
import requests
import math
import time

def get_airport_coordinates(iata_code):
    url = f"https://raw.githubusercontent.com/jpatokal/openflights/master/data/airports.dat"
    response = requests.get(url)
    data = response.text.splitlines()
    for line in data:
        fields = line.split(",")
        if len(fields) > 5 and fields[4].strip('"') == iata_code:
            return float(fields[6]), float(fields[7])
    raise ValueError(f"Invalid IATA code or airport not found: {iata_code}")

def get_station_coordinates(station_name):
    url = "https://nominatim.openstreetmap.org/search"
    params = {"q": f"{station_name} railway station, India", "format": "json", "limit": 1}
    headers = {"User-Agent": "railway-distance-calculator"}
    response = requests.get(url, params=params, headers=headers)
    data = response.json()
    if data:
        return float(data[0]["lat"]), float(data[0]["lon"])
    raise ValueError(f"Railway station not found: {station_name}")

def get_coordinates(location):
    url = "https://nominatim.openstreetmap.org/search"
    params = {"q": location, "format": "json", "limit": 1}
    headers = {"User-Agent": "road-distance-app"}
    response = requests.get(url, params=params, headers=headers)
    data = response.json()
    if data:
        return float(data[0]["lat"]), float(data[0]["lon"])
    raise ValueError(f"Location not found: {location}")

def haversine(lat1, lon1, lat2, lon2):
    R = 6371
    lat1, lon1, lat2, lon2 = map(math.radians, [lat1, lon1, lat2, lon2])
    dlat = lat2 - lat1
    dlon = lon2 - lon1
    a = math.sin(dlat/2)**2 + math.cos(lat1) * math.cos(lat2) * math.sin(dlon/2)**2
    c = 2 * math.atan2(math.sqrt(a), math.sqrt(1-a))
    return R * c

def get_osrm_distance(coord1, coord2, mode="driving"):
    osrm_url = f"http://router.project-osrm.org/route/v1/{mode}/{coord1[1]},{coord1[0]};{coord2[1]},{coord2[0]}?overview=false"
    headers = {"User-Agent": "distance-calculator"}
    response = requests.get(osrm_url, headers=headers)
    data = response.json()
    if "routes" in data and data["routes"]:
        return data["routes"][0]["distance"] / 1000
    raise ValueError("Could not calculate distance.")

def get_emission_factor(mode, distance, fuel_type=None):
    EMISSION_FACTORS = {
        "flight_short": 0.251,
        "flight_medium": 0.178,
        "flight_long": 0.151,
        "train_regular": 0.041,
        "train_highspeed": 0.017,
        "metro": 0.005,
        "car_petrol_short": 0.192,
        "car_petrol_long": 0.142,
        "car_diesel_short": 0.171,
        "car_diesel_long": 0.128,
        "car_electric": 0.050,
        "motorbike_petrol": 0.094,
        "motorbike_electric": 0.020,
        "bicycle": 0.0,
        "jogging": 0.0
    }
    
    mode = mode.lower()
    if "flight" in mode:
        if distance < 1500:
            return EMISSION_FACTORS["flight_short"]
        if distance < 4000:
            return EMISSION_FACTORS["flight_medium"]
        return EMISSION_FACTORS["flight_long"]
    if mode in ["train_regular", "train_highspeed", "metro"]:
        return EMISSION_FACTORS[mode]
    if mode == "car":
        if not fuel_type:
            raise ValueError("Please specify the fuel type for car: petrol, diesel, or electric.")
        if fuel_type == "electric":
            return EMISSION_FACTORS["car_electric"]
        return EMISSION_FACTORS[f"car_{fuel_type}_short"] if distance < 100 else EMISSION_FACTORS[f"car_{fuel_type}_long"]
    if mode == "motorbike":
        if not fuel_type:
            raise ValueError("Please specify the fuel type for motorbike: petrol or electric.")
        return EMISSION_FACTORS[f"motorbike_{fuel_type}"]
    if mode in ["bicycle", "jogging"]:
        return EMISSION_FACTORS[mode]
    raise ValueError("Invalid transport mode.")

def calculate_emission(mode, distance, fuel_type=None):
    emission_factor = get_emission_factor(mode, distance, fuel_type)
    return emission_factor * distance

def lambda_handler(event, context):
    if event["httpMethod"] == "OPTIONS":
        return {
            "statusCode": 200,
            "headers": {
                "Access-Control-Allow-Origin": "*",
                "Access-Control-Allow-Methods": "POST, GET, OPTIONS",
                "Access-Control-Allow-Headers": "Content-Type"
            },
            "body": ""
        }
    
    try:
        body = json.loads(event["body"])
        location1 = body.get("location1")
        location2 = body.get("location2")
        mode = body.get("mode")
        fuel_type = body.get("fuel_type", None)
        
        coord1 = get_coordinates(location1)
        time.sleep(1)
        coord2 = get_coordinates(location2)
        
        distance_km = get_osrm_distance(coord1, coord2)
        emission_factor = get_emission_factor(mode, distance_km, fuel_type)
        emission = calculate_emission(mode, distance_km, fuel_type)
        
        response = {
            "distance_km": distance_km,
            "emission_kg_co2": emission,
            "emission_factor": emission_factor
        }
        return {
            "statusCode": 200,
            "headers": {
                "Access-Control-Allow-Origin": "*",
                "Content-Type": "application/json"
            },
            "body": json.dumps(response)
        }
    except Exception as e:
        return {
            "statusCode": 400,
            "headers": {
                "Access-Control-Allow-Origin": "*",
                "Content-Type": "application/json"
            },
            "body": json.dumps({"error": str(e)})
        }
